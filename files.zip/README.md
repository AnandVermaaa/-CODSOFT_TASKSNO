# CODSOFT Data Science Internship

| Task | File | Dataset |
|------|------|---------|
| 1. Titanic Survival Prediction | task1_titanic.py | Kaggle Titanic (train.csv) |
| 2. Movie Rating Prediction | task2_movie_rating.py | IMDb Movies India.csv |
| 3. Iris Flower Classification | task3_iris.py | built-in / Iris.csv |

Setup: `pip install -r requirements.txt`, then `python task1_titanic.py path/to/train.csv`
