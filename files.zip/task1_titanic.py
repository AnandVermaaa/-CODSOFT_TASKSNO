"""Task 1 - Titanic Survival Prediction
Dataset: Kaggle Titanic 'train.csv' (or Titanic-Dataset.csv). Put it next to this file.
Run: python task1_titanic.py
"""
import sys
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

path = sys.argv[1] if len(sys.argv) > 1 else "train.csv"
df = pd.read_csv(path)
print(df.shape); print(df.isnull().sum())

# ---- EDA ----
sns.countplot(x="Survived", hue="Sex", data=df); plt.title("Survival by sex"); plt.show()
sns.countplot(x="Survived", hue="Pclass", data=df); plt.title("Survival by class"); plt.show()

# ---- Feature engineering ----
df["Title"] = df["Name"].str.extract(r" ([A-Za-z]+)\.", expand=False)
df["Title"] = df["Title"].replace(["Mlle", "Ms"], "Miss").replace("Mme", "Mrs")
common = ["Mr", "Mrs", "Miss", "Master"]
df["Title"] = df["Title"].where(df["Title"].isin(common), "Rare")
df["FamilySize"] = df["SibSp"] + df["Parch"] + 1
df["IsAlone"] = (df["FamilySize"] == 1).astype(int)
df["HasCabin"] = df["Cabin"].notnull().astype(int)

num = ["Age", "Fare", "FamilySize", "IsAlone", "HasCabin", "Pclass"]
cat = ["Sex", "Embarked", "Title"]
X, y = df[num + cat], df["Survived"]

pre = ColumnTransformer([
    ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num),
    ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                      ("oh", OneHotEncoder(handle_unknown="ignore"))]), cat),
])

X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

models = {
    "Logistic Regression": LogisticRegression(max_iter=1000),
    "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=6, random_state=42),
}
best, best_acc = None, 0
for name, m in models.items():
    pipe = Pipeline([("pre", pre), ("model", m)])
    cv = cross_val_score(pipe, X_tr, y_tr, cv=5).mean()
    pipe.fit(X_tr, y_tr)
    acc = accuracy_score(y_te, pipe.predict(X_te))
    print(f"{name}: CV={cv:.3f}  Test={acc:.3f}")
    if acc > best_acc: best, best_acc, best_name = pipe, acc, name

print("\nBest model:", best_name)
pred = best.predict(X_te)
print(classification_report(y_te, pred))
sns.heatmap(confusion_matrix(y_te, pred), annot=True, fmt="d", cmap="Blues")
plt.xlabel("Predicted"); plt.ylabel("Actual"); plt.show()
