"""Task 2 - Movie Rating Prediction (regression)
Dataset: Kaggle 'IMDb Indian Movies' (IMDb Movies India.csv). Put it next to this file.
Columns: Name, Year, Duration, Genre, Rating, Votes, Director, Actor 1, Actor 2, Actor 3
Run: python task2_movie_rating.py
"""
import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

path = sys.argv[1] if len(sys.argv) > 1 else "IMDb Movies India.csv"
df = pd.read_csv(path, encoding="latin-1")
print(df.shape)

# ---- Cleaning ----
df = df.dropna(subset=["Rating"]).copy()
df["Year"] = df["Year"].astype(str).str.extract(r"(\d{4})").astype(float)
df["Duration"] = df["Duration"].astype(str).str.extract(r"(\d+)").astype(float)
df["Votes"] = df["Votes"].astype(str).str.replace(",", "").str.extract(r"(\d+)").astype(float)
for c in ["Genre", "Director", "Actor 1", "Actor 2", "Actor 3"]:
    df[c] = df[c].fillna("Unknown")
for c in ["Year", "Duration", "Votes"]:
    df[c] = df[c].fillna(df[c].median())

# ---- Split first, then target-encode using TRAIN only (avoids leakage) ----
train, test = train_test_split(df, test_size=0.2, random_state=42)
gmean = train["Rating"].mean()

def target_encode(col, k=5):
    stats = train.groupby(col)["Rating"].agg(["mean", "count"])
    smooth = (stats["mean"] * stats["count"] + gmean * k) / (stats["count"] + k)
    return smooth

def build(d):
    X = pd.DataFrame(index=d.index)
    X["Year"], X["Duration"] = d["Year"], d["Duration"]
    X["LogVotes"] = np.log1p(d["Votes"])
    X["GenreCount"] = d["Genre"].str.count(",") + 1
    for c in ["Director", "Actor 1", "Actor 2", "Actor 3"]:
        X[c + "_enc"] = d[c].map(enc[c]).fillna(gmean)
    # main genre encoding (first listed genre)
    X["MainGenre_enc"] = d["Genre"].str.split(",").str[0].str.strip().map(enc["MainGenre"]).fillna(gmean)
    return X

train = train.copy(); test = test.copy()
train["MainGenre"] = train["Genre"].str.split(",").str[0].str.strip()
enc = {c: target_encode(c) for c in ["Director", "Actor 1", "Actor 2", "Actor 3", "MainGenre"]}

X_tr, X_te = build(train), build(test)
y_tr, y_te = train["Rating"], test["Rating"]

for name, m in {"Linear Regression": LinearRegression(),
                "Random Forest": RandomForestRegressor(n_estimators=300, min_samples_leaf=3,
                                                       random_state=42, n_jobs=-1)}.items():
    m.fit(X_tr, y_tr); p = m.predict(X_te)
    print(f"{name}: RMSE={np.sqrt(mean_squared_error(y_te, p)):.3f} "
          f"MAE={mean_absolute_error(y_te, p):.3f} R2={r2_score(y_te, p):.3f}")

# feature importance from the forest
imp = pd.Series(m.feature_importances_, index=X_tr.columns).sort_values()
imp.plot.barh(title="Feature importance (Random Forest)"); plt.tight_layout(); plt.show()
plt.scatter(y_te, p, alpha=.3); plt.plot([1, 10], [1, 10], "r--")
plt.xlabel("Actual"); plt.ylabel("Predicted"); plt.show()
