"""Task 3 - Iris Flower Classification
Uses the built-in sklearn iris data (same as the Kaggle/UCI Iris.csv), or pass a CSV path
with columns SepalLengthCm,SepalWidthCm,PetalLengthCm,PetalWidthCm,Species.
Run: python task3_iris.py
"""
import sys
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

if len(sys.argv) > 1:
    df = pd.read_csv(sys.argv[1]).drop(columns=["Id"], errors="ignore")
    df.columns = ["sepal_length", "sepal_width", "petal_length", "petal_width", "species"]
else:
    d = load_iris(as_frame=True)
    df = d.frame.rename(columns=lambda c: c.replace(" (cm)", "").replace(" ", "_"))
    df["species"] = d.target.map(dict(enumerate(d.target_names)))
    df = df.drop(columns="target")

print(df.head()); print(df["species"].value_counts())
sns.pairplot(df, hue="species"); plt.show()

X, y = df.drop(columns="species"), df["species"]
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

models = {
    "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=500)),
    "KNN": make_pipeline(StandardScaler(), KNeighborsClassifier(5)),
    "SVM": make_pipeline(StandardScaler(), SVC()),
    "Decision Tree": DecisionTreeClassifier(random_state=42),
}
for n, m in models.items():
    print(f"{n}: CV={cross_val_score(m, X_tr, y_tr, cv=5).mean():.3f}")

final = models["SVM"].fit(X_tr, y_tr)
pred = final.predict(X_te)
print("\nTest accuracy:", accuracy_score(y_te, pred))
print(classification_report(y_te, pred))
sns.heatmap(confusion_matrix(y_te, pred), annot=True, fmt="d", cmap="Greens",
            xticklabels=final.classes_, yticklabels=final.classes_)
plt.show()
